import pandas as pd
import re


class DataMerger:
    def __init__(self, original_path, augmented_path, save_path):
        """
        DataMerger 클래스를 초기화하는 메서드.

        Parameters:
        - original_path: 원본 데이터 파일 경로
        - augmented_path: 증강 데이터 파일 경로
        - save_path: 병합된 데이터 저장 경로
        """
        self.original_path = original_path
        self.augmented_path = augmented_path
        self.save_path = save_path

    def preprocess_names(self, data, name_column="name"):
        """
        이름 데이터를 전처리하는 메서드.

        Parameters:
        - data: 데이터프레임
        - name_column: 전처리할 이름 컬럼 이름 (기본값: 'name')

        Returns:
        - data: 전처리된 데이터프레임
        """
        data[name_column] = data[name_column].str.lower()  # 소문자 통일
        data[name_column] = data[name_column].apply(
            lambda x: re.sub(r"[^a-zA-Z\s]", "", x)
        )  # 특수문자 제거
        data[name_column] = data[name_column].str.strip()  # 앞뒤 공백 제거
        return data

    def load_data(self):
        """
        원본 및 증강 데이터를 로드하는 메서드.

        Returns:
        - original_data: 원본 데이터프레임
        - augmented_data: 증강 데이터프레임
        """
        original_data = pd.read_csv(self.original_path)
        augmented_data = pd.read_csv(self.augmented_path)
        return original_data, augmented_data

    def merge_and_save(self):
        """
        원본 데이터(예: train.csv)와 증강 데이터를 병합하고 저장하는 메서드.

        Returns:
        - merged_data: 병합된 데이터프레임
        """

        original_data, augmented_data = self.load_data()

        # 데이터 병합 진행
        original_data.columns = original_data.columns.str.lower()
        augmented_data.columns = augmented_data.columns.str.lower()

        original_data = self.preprocess_names(original_data, name_column="name")
        augmented_data = self.preprocess_names(augmented_data, name_column="name")

        merged_data = pd.merge(
            original_data, augmented_data, on="name", how="left", suffixes=("", "_drop")
        )
        merged_data = (
            merged_data.drop_duplicates()
            .filter(regex="^(?!.*_drop)")
            .reset_index(drop=True)
        )

        # 병합 후 데이터가 원본 데이터와 동일한 길이인지 확인
        if len(merged_data) != len(original_data):
            raise ValueError(
                "Merged data length does not match the original data length."
            )

        merged_data.to_csv(self.save_path, index=False)
        return merged_data
