import streamlit as st

# 타이틀 적용 예시
st.title('이것은 타이틀 입니다')

# 특수 이모티콘 삽입 예시
# emoji: https://streamlit-emoji-shortcodes-streamlit-app-gwckff.streamlit.app/
st.title('스마일 :sunglasses:')